<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%
String usuario = request.getParameter("usuario");
String senha = request.getParameter("senha");

if ("admin".equals(usuario) && "123".equals(senha)) {
    response.sendRedirect("dashboard.html");
} else {
    response.sendRedirect("index.html");
}
%>
