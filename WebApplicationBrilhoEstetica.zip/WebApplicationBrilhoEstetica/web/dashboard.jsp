<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>

    <h1>Bem-vindo ao Sistema de Estética Automotiva!</h1>

    <p>Login realizado com sucesso.</p>

    <a href="index.html">Sair</a>

</body>
</html>